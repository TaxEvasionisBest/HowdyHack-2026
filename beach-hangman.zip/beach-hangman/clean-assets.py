#!/usr/bin/env python3
"""Maps the Figma export UUID filenames to readable names and strips the opaque
ancestor backdrops (page / card / scene / pill rectangles) that Figma baked into each
SVG export. Layer artwork itself is not modified. Originals stay in assets/_original/."""
import os, re, shutil, xml.etree.ElementTree as ET
SRC = os.environ.get("SRC", "upload")
NAMES = {"085b2392":"clock","0e0e69cd":"wave-mark","27992727":"circle-help","2bae11f4":"hangman-body",
"3e5b1244":"umbrella-pole","3fd45dbb":"shell","4403a872":"volume-x","474ff03a":"rotate-cw","4a5c695d":"sand-details",
"4aee454e":"arrow-right","60344c28":"sandy-beach","605d87b8":"scaffold-shadow","6f500f46":"seashell","79076744":"sun",
"8393d306":"lightbulb","8aa5f36b":"keyboard","9596710b":"sun-disc","a045fffd":"driftwood-frame","a57b659d":"umbrella-canopy",
"b25cc3d2":"distant-birds","bc69f69c":"sun-halo","d2a15b21":"sea-ripples","d466930c":"cloud","d57a2533":"umbrella-stripe",
"db68f5a4":"shore-foam","dd9e8afc":"hangman-head","f8cb5384":"info","7de176e8":"alphabet-keyboard"}
NS = "http://www.w3.org/2000/svg"; ET.register_namespace("", NS)
tag = lambda e: e.tag.split("}")[1]
here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "assets")
for f in sorted(os.listdir(SRC)):
    key = f[:8]
    if key not in NAMES: continue
    ext = os.path.splitext(f)[1]; name = NAMES[key] + ext
    shutil.copy(os.path.join(SRC, f), os.path.join(out, "_original", name))
    if ext != ".svg":
        shutil.copy(os.path.join(SRC, f), os.path.join(out, name)); continue
    root = ET.parse(os.path.join(SRC, f)).getroot()
    for r in [c for c in root if tag(c) == "rect"]: root.remove(r)   # dark #1E1E1E canvas
    node = root
    while True:
        groups = [c for c in node if tag(c) == "g"]
        if len(groups) != 1: break
        for c in [c for c in node if tag(c) == "rect"] if node is not root else []: node.remove(c)
        node.attrib.pop("filter", None)
        node = groups[0]
        if not [c for c in node if tag(c) == "g"]: break
    ET.ElementTree(root).write(os.path.join(out, name), xml_declaration=False)
print("ok")
