(() => {
  "use strict";

  const MAX_WRONG = 6;
  const ROUND_MS = 60000;
  const WARN_AT = 10; // seconds

  const WORDS = [
    ["SEASHELL", "Beach treasures", "A little ocean souvenir, washed up on the sand."],
    ["STARFISH", "Beach treasures", "A five-armed critter that clings to tide pool rocks."],
    ["DRIFTWOOD", "Beach treasures", "Sun-bleached timber the waves have carried in."],
    ["SANDDOLLAR", "Beach treasures", "A flat, round shell that looks like a coin."],
    ["SURFBOARD", "Beach gear", "You stand on it to ride a wave."],
    ["UMBRELLA", "Beach gear", "It makes a patch of shade on the sand."],
    ["SUNSCREEN", "Beach gear", "Slather it on before the midday glare."],
    ["SNORKEL", "Beach gear", "A breathing tube for peeking under the surface."],
    ["BEACHBALL", "Beach gear", "Striped, inflatable and always bouncing around."],
    ["HAMMOCK", "Beach gear", "A hanging bed strung between two palm trees."],
    ["PELICAN", "Seaside life", "A big-billed bird that scoops up fish."],
    ["SEAGULL", "Seaside life", "It will steal your chips if you look away."],
    ["DOLPHIN", "Seaside life", "A playful swimmer that leaps beside boats."],
    ["LIGHTHOUSE", "Seaside spots", "A tall tower that guides ships at night."],
    ["LAGOON", "Seaside spots", "A calm, shallow pool sheltered by a reef."],
    ["TIDEPOOL", "Seaside spots", "A small rocky puddle the sea leaves behind."]
  ];

  const ROWS = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];
  const $ = (s) => document.querySelector(s);
  const el = {
    scene: $("#scene"), parts: document.querySelectorAll(".part"),
    capTitle: $("#capTitle"), capText: $("#capText"),
    category: $("#category"), dots: $("#dots"), guessText: $("#guessText"),
    play: $("#play"), slots: $("#slots"), slotMeta: $("#slotMeta"), hint: $("#hint"),
    keys: $("#keys"), missedList: $("#missedList"), newBtn: $("#newBtn"),
    result: $("#result"), rLabel: $("#rLabel"), rTitle: $("#rTitle"), rText: $("#rText"),
    rSlots: $("#rSlots"), againBtn: $("#againBtn"), againLabel: $("#againLabel"),
    timer: $("#timer"), timerText: $("#timerText"), timerNote: $("#timerNote"),
    live: $("#live"), help: $("#helpDialog"), helpBtn: $("#helpBtn"), helpClose: $("#helpClose"),
    soundBtn: $("#soundBtn"), sceneWrap: $("#sceneWrap")
  };

  let st = null;          // round state
  let timerId = null;
  let lastWord = "";
  let soundOn = false;
  let audio = null;

  /* ---------- helpers ---------- */
  const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  const wrongs = () => st.guessed.filter((l) => !st.word.includes(l));
  const left = () => MAX_WRONG - wrongs().length;
  const solved = () => [...st.word].every((l) => st.guessed.includes(l));

  function announce(msg) {
    el.live.textContent = "";
    setTimeout(() => { el.live.textContent = msg; }, 30);
  }

  function beep(freq) {
    if (!soundOn) return;
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      const o = audio.createOscillator(), g = audio.createGain();
      o.frequency.value = freq; g.gain.value = 0.05;
      o.connect(g); g.connect(audio.destination);
      o.start(); o.stop(audio.currentTime + 0.12);
    } catch (e) { /* sound never affects the game */ }
  }

  /* ---------- keyboard ---------- */
  function buildKeys() {
    el.keys.innerHTML = "";
    ROWS.forEach((row) => {
      const r = document.createElement("div");
      r.className = "krow";
      [...row].forEach((l) => {
        const b = document.createElement("button");
        b.type = "button"; b.className = "key"; b.dataset.letter = l; b.textContent = l;
        r.appendChild(b);
      });
      el.keys.appendChild(r);
    });
  }

  function renderKeys() {
    el.keys.querySelectorAll(".key").forEach((b) => {
      const l = b.dataset.letter;
      b.classList.remove("hit", "miss", "locked");
      if (st.guessed.includes(l)) {
        const hit = st.word.includes(l);
        b.classList.add(hit ? "hit" : "miss");
        b.setAttribute("aria-disabled", "true");
        b.setAttribute("aria-label", `${l}, ${hit ? "in the word" : "not in the word"}`);
      } else if (st.status !== "playing") {
        b.classList.add("locked");
        b.setAttribute("aria-disabled", "true");
        b.setAttribute("aria-label", `${l}, locked`);
      } else {
        b.removeAttribute("aria-disabled");
        b.setAttribute("aria-label", l);
      }
    });
  }

  /* ---------- word slots ---------- */
  function renderSlots(box, reveal) {
    box.innerHTML = "";
    box.style.setProperty("--n", st.word.length);
    box.setAttribute("aria-label", `Word with ${st.word.length} letters`);
    [...st.word].forEach((l) => {
      const found = st.guessed.includes(l);
      const s = document.createElement("div");
      s.className = "slot" + (found ? " on" : "") + (!found && reveal ? " miss" : "");
      s.setAttribute("role", "img");
      s.setAttribute("aria-label", found || reveal ? l : "Unknown letter");
      s.innerHTML = `<b aria-hidden="true">${found || reveal ? l : ""}</b><u></u>`;
      if (reveal && !found) s.querySelector("u").style.background = "";
      box.appendChild(s);
    });
  }

  /* ---------- render ---------- */
  function render() {
    const w = wrongs().length;
    const lost = st.status === "lost";
    el.parts.forEach((p) => p.classList.toggle("on", lost || Number(p.dataset.part) <= w));
    el.scene.classList.toggle("win", st.status === "won");

    el.category.textContent = st.cat;
    el.dots.innerHTML = "";
    for (let i = 0; i < MAX_WRONG; i++) {
      const d = document.createElement("i");
      if (i < left()) d.className = "on";
      el.dots.appendChild(d);
    }
    el.guessText.textContent = `${left()} of ${MAX_WRONG} guesses left`;

    const playing = st.status === "playing";
    el.play.hidden = !playing;
    el.result.hidden = playing;
    el.result.className = "result" + (st.status === "won" ? " win" : st.status === "lost" ? " loss" : "");
    el.result.hidden = playing;

    if (playing) {
      renderSlots(el.slots, false);
      el.slotMeta.textContent = `${st.word.length} letters · One beachy little mystery`;
      el.hint.textContent = `Hint: ${st.hint}`;
      const miss = wrongs();
      el.missedList.textContent = miss.length ? miss.join(", ") : "none yet";
      el.capTitle.textContent = "A shore thing? Not quite.";
      el.capText.innerHTML = "Every letter brings you closer.<br>Take a breath and catch the next one.";
    } else {
      const spare = left();
      if (st.status === "won") {
        el.rLabel.textContent = "WIN · WORD COMPLETED";
        el.rTitle.textContent = "You’re on a shore streak!";
        el.rText.textContent = `You found ${st.word} with ${spare} ${spare === 1 ? "guess" : "guesses"} to spare.`;
        el.againLabel.textContent = "Play again";
        el.capTitle.textContent = "A shore thing!";
        el.capText.innerHTML = "The sun is out and the word is yours.<br>Ready for another wave?";
      } else {
        const timeout = st.reason === "time";
        el.rLabel.textContent = timeout ? "LOSS · TIME’S UP" : "LOSS · 0 GUESSES LEFT";
        el.rTitle.textContent = timeout ? "Time’s up!" : "Tide’s out. Try again?";
        el.rText.textContent = `The word was ${st.word}. A new wave is waiting.`;
        el.againLabel.textContent = "Try another word";
        el.capTitle.textContent = "Tide’s out.";
        el.capText.innerHTML = "Every shore has a next wave.<br>Take a breath and try again.";
      }
      renderSlots(el.rSlots, st.status === "lost");
    }
    renderKeys();
    renderTimer();
  }

  function secondsLeft() {
    return Math.max(0, Math.ceil((st.deadline - Date.now()) / 1000));
  }

  function renderTimer() {
    const s = st.status === "playing" ? secondsLeft() : st.frozen;
    const warn = st.status === "playing" && s <= WARN_AT;
    el.timer.classList.toggle("warn", warn);
    el.timerText.textContent = `${fmt(s)} remaining${warn ? " · Hurry!" : ""}`;
    el.timer.setAttribute("aria-label", `${fmt(s)} remaining`);
    el.timerNote.textContent = st.status === "playing"
      ? "The round ends when the timer runs out."
      : "Round over. The timer has stopped.";
  }

  /* ---------- game flow ---------- */
  function tick() {
    if (!st || st.status !== "playing") return;
    const s = secondsLeft();
    if (s <= WARN_AT && !st.warned) {
      st.warned = true;
      announce(`${WARN_AT} seconds left.`);
    }
    if (s <= 0) { endRound("lost", "time"); return; }
    renderTimer();
  }

  function stopTimer() {
    clearInterval(timerId);
    timerId = null;
  }

  function endRound(status, reason) {
    if (st.status !== "playing") return;
    st.frozen = Math.min(secondsLeft(), 60);
    stopTimer();
    st.status = status;
    st.reason = reason;
    if (reason === "time") st.frozen = 0;
    render();
    const msg = status === "won"
      ? `You won! You found ${st.word}.`
      : reason === "time" ? `Time’s up! The word was ${st.word}.` : `Out of guesses. The word was ${st.word}.`;
    announce(msg);
    beep(status === "won" ? 660 : 220);
    el.againBtn.focus();
  }

  function newGame(refocus) {
    stopTimer();
    const pool = WORDS.filter((w) => w[0] !== lastWord);
    const pick = pool[Math.floor(Math.random() * pool.length)];
    lastWord = pick[0];
    st = {
      word: pick[0], cat: pick[1], hint: pick[2],
      guessed: [], status: "playing", reason: "", warned: false, frozen: 60,
      deadline: Date.now() + ROUND_MS
    };
    render();
    timerId = setInterval(tick, 250);
    announce(`New round. ${st.cat}. ${st.word.length} letters. ${MAX_WRONG} guesses and 60 seconds.`);
    if (refocus === true) el.keys.querySelector(".key").focus({ preventScroll: true });
  }

  function guess(letter) {
    if (!st || st.status !== "playing" || !/^[A-Z]$/.test(letter) || st.guessed.includes(letter)) return;
    st.guessed.push(letter);
    const hit = st.word.includes(letter);
    beep(hit ? 520 : 260);
    if (solved()) { renderKeys(); endRound("won", ""); return; }
    if (left() <= 0) { endRound("lost", "guesses"); return; }
    render();
    announce(`${letter}. ${hit ? "In the word" : "Not in the word"}. ${left()} of ${MAX_WRONG} guesses left.`);
  }

  /* ---------- events ---------- */
  el.keys.addEventListener("click", (e) => {
    const b = e.target.closest(".key");
    if (b) guess(b.dataset.letter);
  });

  document.addEventListener("keydown", (e) => {
    if (e.repeat || e.ctrlKey || e.metaKey || e.altKey || el.help.open) return;
    if (e.key.length === 1 && /^[a-z]$/i.test(e.key)) guess(e.key.toUpperCase());
  });

  el.newBtn.addEventListener("click", () => newGame(true));
  el.againBtn.addEventListener("click", () => newGame(true));

  el.helpBtn.addEventListener("click", () => el.help.showModal());
  el.helpClose.addEventListener("click", () => el.help.close());
  el.help.addEventListener("click", (e) => { if (e.target === el.help) el.help.close(); });

  el.soundBtn.addEventListener("click", () => {
    soundOn = !soundOn;
    el.soundBtn.setAttribute("aria-pressed", String(soundOn));
    el.soundBtn.setAttribute("aria-label", soundOn ? "Sound on. Turn sound off" : "Sound off. Turn sound on");
    beep(440);
  });

  document.addEventListener("visibilitychange", tick);

  function fit() { el.scene.style.transform = `scale(${el.sceneWrap.clientWidth / 460})`; }
  if ("ResizeObserver" in window) new ResizeObserver(fit).observe(el.sceneWrap);
  window.addEventListener("resize", fit);
  fit();

  buildKeys();
  newGame(false);
})();
